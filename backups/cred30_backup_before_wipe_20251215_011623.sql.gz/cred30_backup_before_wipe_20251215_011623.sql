--
-- PostgreSQL database dump
--

\restrict TAngJH79y1TeqQnpNIRMcbOiwWrw1VagTbn1BMuXh6OPcwHfZqxvoqfhJCjnPGJ

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

-- Started on 2025-12-15 04:16:24 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.withdrawals DROP CONSTRAINT withdrawals_user_id_fkey;
ALTER TABLE ONLY public.transactions DROP CONSTRAINT transactions_user_id_fkey;
ALTER TABLE ONLY public.quotas DROP CONSTRAINT quotas_user_id_fkey;
ALTER TABLE ONLY public.loans DROP CONSTRAINT loans_user_id_fkey;
ALTER TABLE ONLY public.loan_installments DROP CONSTRAINT loan_installments_loan_id_fkey;
DROP TRIGGER update_withdrawals_updated_at ON public.withdrawals;
DROP TRIGGER update_users_updated_at ON public.users;
DROP TRIGGER update_quotas_updated_at ON public.quotas;
DROP TRIGGER update_loans_updated_at ON public.loans;
DROP TRIGGER update_loan_installments_updated_at ON public.loan_installments;
DROP TRIGGER update_app_settings_updated_at ON public.app_settings;
DROP INDEX public.idx_withdrawals_user_id;
DROP INDEX public.idx_withdrawals_status;
DROP INDEX public.idx_users_email;
DROP INDEX public.idx_transactions_user_id;
DROP INDEX public.idx_transactions_type;
DROP INDEX public.idx_rate_limit_identifier;
DROP INDEX public.idx_rate_limit_created_at;
DROP INDEX public.idx_quotas_user_id;
DROP INDEX public.idx_loans_user_id;
DROP INDEX public.idx_loans_status;
DROP INDEX public.idx_loan_installments_status;
DROP INDEX public.idx_loan_installments_loan_id;
DROP INDEX public.idx_audit_logs_entity;
DROP INDEX public.idx_audit_logs_created_at;
DROP INDEX public.idx_audit_logs_action;
DROP INDEX public.idx_admin_logs_entity;
DROP INDEX public.idx_admin_logs_created_at;
DROP INDEX public.idx_admin_logs_admin_id;
ALTER TABLE ONLY public.withdrawals DROP CONSTRAINT withdrawals_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.transactions DROP CONSTRAINT transactions_pkey;
ALTER TABLE ONLY public.system_config DROP CONSTRAINT system_config_pkey;
ALTER TABLE ONLY public.rate_limit_logs DROP CONSTRAINT rate_limit_logs_pkey;
ALTER TABLE ONLY public.quotas DROP CONSTRAINT quotas_pkey;
ALTER TABLE ONLY public.loans DROP CONSTRAINT loans_pkey;
ALTER TABLE ONLY public.loan_installments DROP CONSTRAINT loan_installments_pkey;
ALTER TABLE ONLY public.audit_logs DROP CONSTRAINT audit_logs_pkey;
ALTER TABLE ONLY public.app_settings DROP CONSTRAINT app_settings_pkey;
ALTER TABLE ONLY public.admin_logs DROP CONSTRAINT admin_logs_pkey;
ALTER TABLE public.system_config ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.rate_limit_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.audit_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.admin_logs ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.withdrawals;
DROP TABLE public.users;
DROP TABLE public.transactions;
DROP SEQUENCE public.system_config_id_seq;
DROP TABLE public.system_config;
DROP SEQUENCE public.rate_limit_logs_id_seq;
DROP TABLE public.rate_limit_logs;
DROP TABLE public.quotas;
DROP TABLE public.loans;
DROP TABLE public.loan_installments;
DROP SEQUENCE public.audit_logs_id_seq;
DROP TABLE public.audit_logs;
DROP TABLE public.app_settings;
DROP SEQUENCE public.admin_logs_id_seq;
DROP TABLE public.admin_logs;
DROP FUNCTION public.update_updated_at_column();
DROP EXTENSION "uuid-ossp";
--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 3575 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 242 (class 1255 OID 25625)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 220 (class 1259 OID 16572)
-- Name: admin_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_logs (
    id integer NOT NULL,
    admin_id integer,
    action character varying(50) NOT NULL,
    entity_type character varying(20) NOT NULL,
    entity_id character varying(50),
    old_values jsonb,
    new_values jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 219 (class 1259 OID 16571)
-- Name: admin_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3576 (class 0 OID 0)
-- Dependencies: 219
-- Name: admin_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_logs_id_seq OWNED BY public.admin_logs.id;


--
-- TOC entry 230 (class 1259 OID 25593)
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_settings (
    key character varying(100) NOT NULL,
    value text NOT NULL,
    description text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 224 (class 1259 OID 16701)
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    action character varying(100) NOT NULL,
    entity_id integer,
    entity_type character varying(50),
    details text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 223 (class 1259 OID 16700)
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3577 (class 0 OID 0)
-- Dependencies: 223
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- TOC entry 231 (class 1259 OID 25601)
-- Name: loan_installments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loan_installments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    loan_id uuid,
    installment_number integer NOT NULL,
    amount numeric(15,2) NOT NULL,
    due_date timestamp without time zone NOT NULL,
    paid_at timestamp without time zone,
    status character varying(50) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 227 (class 1259 OID 25549)
-- Name: loans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loans (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    amount numeric(15,2) NOT NULL,
    interest_rate numeric(5,4) NOT NULL,
    penalty_rate numeric(5,4) NOT NULL,
    term_days integer NOT NULL,
    total_repayment numeric(15,2) NOT NULL,
    installments integer DEFAULT 1,
    status character varying(50) DEFAULT 'pending'::character varying,
    approved_at timestamp without time zone,
    due_date timestamp without time zone,
    pix_key_to_receive character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 226 (class 1259 OID 25534)
-- Name: quotas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotas (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    purchase_price numeric(10,2) NOT NULL,
    current_value numeric(10,2) NOT NULL,
    purchase_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 222 (class 1259 OID 16590)
-- Name: rate_limit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_limit_logs (
    id integer NOT NULL,
    identifier character varying(100) NOT NULL,
    user_id integer,
    count integer NOT NULL,
    ip_address text,
    user_agent text,
    endpoint character varying(200),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 221 (class 1259 OID 16589)
-- Name: rate_limit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rate_limit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3578 (class 0 OID 0)
-- Dependencies: 221
-- Name: rate_limit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rate_limit_logs_id_seq OWNED BY public.rate_limit_logs.id;


--
-- TOC entry 218 (class 1259 OID 16558)
-- Name: system_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_config (
    id integer NOT NULL,
    system_balance numeric(15,2) DEFAULT 0,
    profit_pool numeric(15,2) DEFAULT 0,
    quota_price numeric(10,2) DEFAULT 100,
    loan_interest_rate numeric(5,2) DEFAULT 0.2,
    penalty_rate numeric(5,2) DEFAULT 0.4,
    vesting_period_ms bigint DEFAULT '31536000000'::bigint,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 217 (class 1259 OID 16557)
-- Name: system_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3579 (class 0 OID 0)
-- Dependencies: 217
-- Name: system_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_config_id_seq OWNED BY public.system_config.id;


--
-- TOC entry 228 (class 1259 OID 25564)
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    type character varying(50) NOT NULL,
    amount numeric(15,2) NOT NULL,
    description text,
    reference_id uuid,
    status character varying(50) DEFAULT 'completed'::character varying,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 225 (class 1259 OID 25518)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    secret_phrase character varying(255) NOT NULL,
    pix_key character varying(255) NOT NULL,
    referral_code character varying(20) NOT NULL,
    is_admin boolean DEFAULT false,
    role character varying(50) DEFAULT 'client'::character varying,
    balance numeric(15,2) DEFAULT 0.00,
    total_invested numeric(15,2) DEFAULT 0.00,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 229 (class 1259 OID 25579)
-- Name: withdrawals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.withdrawals (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    amount numeric(15,2) NOT NULL,
    pix_key character varying(255) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 3325 (class 2604 OID 16575)
-- Name: admin_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_logs ALTER COLUMN id SET DEFAULT nextval('public.admin_logs_id_seq'::regclass);


--
-- TOC entry 3329 (class 2604 OID 16704)
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- TOC entry 3327 (class 2604 OID 16593)
-- Name: rate_limit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limit_logs ALTER COLUMN id SET DEFAULT nextval('public.rate_limit_logs_id_seq'::regclass);


--
-- TOC entry 3317 (class 2604 OID 16561)
-- Name: system_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_config ALTER COLUMN id SET DEFAULT nextval('public.system_config_id_seq'::regclass);


--
-- TOC entry 3558 (class 0 OID 16572)
-- Dependencies: 220
-- Data for Name: admin_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_logs (id, admin_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent, created_at) FROM stdin;
1	1	PROCESS_ACTION	TRANSACTION_LOAN	1	\N	{"id": 1, "type": "TRANSACTION", "action": "REJECT"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 01:39:49.83261
2	1	REJECT_WITHDRAWAL	TRANSACTION	\N	\N	{"transactionId": 2}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 01:39:52.266497
3	1	PROCESS_ACTION	TRANSACTION_LOAN	4	\N	{"id": 4, "type": "TRANSACTION", "action": "APPROVE"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 02:04:16.30318
4	1	PROCESS_ACTION	TRANSACTION_LOAN	1	\N	{"id": 1, "type": "LOAN", "action": "APPROVE"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 02:05:08.014804
5	1	APPROVE_WITHDRAWAL	TRANSACTION	\N	\N	{"transactionId": 6}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 02:06:23.595412
6	1	APPROVE_PAYMENT	TRANSACTION	\N	\N	{"transactionId": 7}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 02:19:42.039434
7	1	PROCESS_ACTION	TRANSACTION_LOAN	2	\N	{"id": 2, "type": "LOAN", "action": "APPROVE"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 02:32:33.856725
8	1	APPROVE_PAYMENT	TRANSACTION	\N	\N	{"transactionId": 9}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 02:33:50.700419
9	1	APPROVE_WITHDRAWAL	TRANSACTION	\N	\N	{"transactionId": 10}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 02:35:18.927022
10	1	PROCESS_ACTION	TRANSACTION_LOAN	11	\N	{"id": 11, "type": "TRANSACTION", "action": "APPROVE"}	179.63.92.49	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 20:05:28.214262
11	1	APPROVE_WITHDRAWAL	TRANSACTION	\N	\N	{"transactionId": 10}	179.63.92.49	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 20:06:09.310229
12	1	APPROVE_WITHDRAWAL	TRANSACTION	\N	\N	{"transactionId": 10}	179.63.92.49	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2025-12-14 20:06:20.807328
\.


--
-- TOC entry 3568 (class 0 OID 25593)
-- Dependencies: 230
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_settings (key, value, description, updated_at) FROM stdin;
quota_price	50	Preço unitário das cotas de investimento	2025-12-14 21:05:37.626571
loan_interest_rate	0.2	Taxa de juros dos empréstimos (20%)	2025-12-14 21:05:37.626571
penalty_rate	0.4	Taxa de multa por atraso (40%)	2025-12-14 21:05:37.626571
admin_pix_key	admin@pix.local	Chave PIX do administrador	2025-12-14 21:05:37.626571
min_loan_amount	100	Valor mínimo de empréstimo	2025-12-14 21:05:37.626571
max_loan_amount	10000	Valor máximo de empréstimo	2025-12-14 21:05:37.626571
\.


--
-- TOC entry 3562 (class 0 OID 16701)
-- Dependencies: 224
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, action, entity_id, entity_type, details, created_by, created_at) FROM stdin;
\.


--
-- TOC entry 3569 (class 0 OID 25601)
-- Dependencies: 231
-- Data for Name: loan_installments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loan_installments (id, loan_id, installment_number, amount, due_date, paid_at, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3565 (class 0 OID 25549)
-- Dependencies: 227
-- Data for Name: loans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loans (id, user_id, amount, interest_rate, penalty_rate, term_days, total_repayment, installments, status, approved_at, due_date, pix_key_to_receive, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3564 (class 0 OID 25534)
-- Dependencies: 226
-- Data for Name: quotas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotas (id, user_id, quantity, unit_price, total_amount, purchase_price, current_value, purchase_date, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3560 (class 0 OID 16590)
-- Dependencies: 222
-- Data for Name: rate_limit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rate_limit_logs (id, identifier, user_id, count, ip_address, user_agent, endpoint, created_at) FROM stdin;
\.


--
-- TOC entry 3556 (class 0 OID 16558)
-- Dependencies: 218
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_config (id, system_balance, profit_pool, quota_price, loan_interest_rate, penalty_rate, vesting_period_ms, updated_at) FROM stdin;
1	1299.20	38.80	50.00	0.20	0.40	31536000000	2025-12-14 01:39:31.242672
\.


--
-- TOC entry 3566 (class 0 OID 25564)
-- Dependencies: 228
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, user_id, type, amount, description, reference_id, status, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 3563 (class 0 OID 25518)
-- Dependencies: 225
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, password_hash, secret_phrase, pix_key, referral_code, is_admin, role, balance, total_invested, created_at, updated_at) FROM stdin;
afd7ead6-61d5-4c33-9b55-0323f7dffd48	josias	josiassm701@gmail.com	$2b$10$LQ2wEWRujApj4SqgzAyZyObiyUTMm/L.V4WZnJehreoNbQOHLKecC	32588589	01558516247	7FCMLE	t	client	0.00	0.00	2025-12-14 21:06:20.751067	2025-12-14 21:06:20.751067
\.


--
-- TOC entry 3567 (class 0 OID 25579)
-- Dependencies: 229
-- Data for Name: withdrawals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.withdrawals (id, user_id, amount, pix_key, status, processed_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3580 (class 0 OID 0)
-- Dependencies: 219
-- Name: admin_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_logs_id_seq', 12, true);


--
-- TOC entry 3581 (class 0 OID 0)
-- Dependencies: 223
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- TOC entry 3582 (class 0 OID 0)
-- Dependencies: 221
-- Name: rate_limit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rate_limit_logs_id_seq', 1, false);


--
-- TOC entry 3583 (class 0 OID 0)
-- Dependencies: 217
-- Name: system_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_config_id_seq', 1, true);


--
-- TOC entry 3363 (class 2606 OID 16580)
-- Name: admin_logs admin_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_logs
    ADD CONSTRAINT admin_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3397 (class 2606 OID 25600)
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- TOC entry 3372 (class 2606 OID 16709)
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3401 (class 2606 OID 25609)
-- Name: loan_installments loan_installments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_installments
    ADD CONSTRAINT loan_installments_pkey PRIMARY KEY (id);


--
-- TOC entry 3387 (class 2606 OID 25558)
-- Name: loans loans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loans
    ADD CONSTRAINT loans_pkey PRIMARY KEY (id);


--
-- TOC entry 3383 (class 2606 OID 25543)
-- Name: quotas quotas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotas
    ADD CONSTRAINT quotas_pkey PRIMARY KEY (id);


--
-- TOC entry 3370 (class 2606 OID 16598)
-- Name: rate_limit_logs rate_limit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limit_logs
    ADD CONSTRAINT rate_limit_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3361 (class 2606 OID 16570)
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (id);


--
-- TOC entry 3391 (class 2606 OID 25573)
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- TOC entry 3378 (class 2606 OID 25533)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3380 (class 2606 OID 25531)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3395 (class 2606 OID 25587)
-- Name: withdrawals withdrawals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.withdrawals
    ADD CONSTRAINT withdrawals_pkey PRIMARY KEY (id);


--
-- TOC entry 3364 (class 1259 OID 16586)
-- Name: idx_admin_logs_admin_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_logs_admin_id ON public.admin_logs USING btree (admin_id);


--
-- TOC entry 3365 (class 1259 OID 16587)
-- Name: idx_admin_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_logs_created_at ON public.admin_logs USING btree (created_at);


--
-- TOC entry 3366 (class 1259 OID 16588)
-- Name: idx_admin_logs_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_logs_entity ON public.admin_logs USING btree (entity_type, entity_id);


--
-- TOC entry 3373 (class 1259 OID 16715)
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- TOC entry 3374 (class 1259 OID 16717)
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- TOC entry 3375 (class 1259 OID 16716)
-- Name: idx_audit_logs_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_entity ON public.audit_logs USING btree (entity_type, entity_id);


--
-- TOC entry 3398 (class 1259 OID 25623)
-- Name: idx_loan_installments_loan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_loan_installments_loan_id ON public.loan_installments USING btree (loan_id);


--
-- TOC entry 3399 (class 1259 OID 25624)
-- Name: idx_loan_installments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_loan_installments_status ON public.loan_installments USING btree (status);


--
-- TOC entry 3384 (class 1259 OID 25618)
-- Name: idx_loans_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_loans_status ON public.loans USING btree (status);


--
-- TOC entry 3385 (class 1259 OID 25617)
-- Name: idx_loans_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_loans_user_id ON public.loans USING btree (user_id);


--
-- TOC entry 3381 (class 1259 OID 25616)
-- Name: idx_quotas_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quotas_user_id ON public.quotas USING btree (user_id);


--
-- TOC entry 3367 (class 1259 OID 16605)
-- Name: idx_rate_limit_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_limit_created_at ON public.rate_limit_logs USING btree (created_at);


--
-- TOC entry 3368 (class 1259 OID 16604)
-- Name: idx_rate_limit_identifier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_limit_identifier ON public.rate_limit_logs USING btree (identifier);


--
-- TOC entry 3388 (class 1259 OID 25620)
-- Name: idx_transactions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_type ON public.transactions USING btree (type);


--
-- TOC entry 3389 (class 1259 OID 25619)
-- Name: idx_transactions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_user_id ON public.transactions USING btree (user_id);


--
-- TOC entry 3376 (class 1259 OID 25615)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3392 (class 1259 OID 25622)
-- Name: idx_withdrawals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_withdrawals_status ON public.withdrawals USING btree (status);


--
-- TOC entry 3393 (class 1259 OID 25621)
-- Name: idx_withdrawals_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_withdrawals_user_id ON public.withdrawals USING btree (user_id);


--
-- TOC entry 3411 (class 2620 OID 25631)
-- Name: app_settings update_app_settings_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_app_settings_updated_at BEFORE UPDATE ON public.app_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3412 (class 2620 OID 25630)
-- Name: loan_installments update_loan_installments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_loan_installments_updated_at BEFORE UPDATE ON public.loan_installments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3409 (class 2620 OID 25628)
-- Name: loans update_loans_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_loans_updated_at BEFORE UPDATE ON public.loans FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3408 (class 2620 OID 25627)
-- Name: quotas update_quotas_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_quotas_updated_at BEFORE UPDATE ON public.quotas FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3407 (class 2620 OID 25626)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3410 (class 2620 OID 25629)
-- Name: withdrawals update_withdrawals_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_withdrawals_updated_at BEFORE UPDATE ON public.withdrawals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3406 (class 2606 OID 25610)
-- Name: loan_installments loan_installments_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_installments
    ADD CONSTRAINT loan_installments_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.loans(id) ON DELETE CASCADE;


--
-- TOC entry 3403 (class 2606 OID 25559)
-- Name: loans loans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loans
    ADD CONSTRAINT loans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3402 (class 2606 OID 25544)
-- Name: quotas quotas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotas
    ADD CONSTRAINT quotas_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3404 (class 2606 OID 25574)
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3405 (class 2606 OID 25588)
-- Name: withdrawals withdrawals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.withdrawals
    ADD CONSTRAINT withdrawals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


-- Completed on 2025-12-15 04:16:24 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict TAngJH79y1TeqQnpNIRMcbOiwWrw1VagTbn1BMuXh6OPcwHfZqxvoqfhJCjnPGJ

